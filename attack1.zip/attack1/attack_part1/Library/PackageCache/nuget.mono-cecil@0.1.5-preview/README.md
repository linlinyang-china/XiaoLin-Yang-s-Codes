# Mono Cecil
https://www.nuget.org/packages/Mono.Cecil/

Version 0.10.0